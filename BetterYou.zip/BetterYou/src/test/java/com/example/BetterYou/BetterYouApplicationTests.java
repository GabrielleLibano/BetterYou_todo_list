package com.example.BetterYou;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BetterYouApplicationTests {

	@Test
	void contextLoads() {
	}

}
