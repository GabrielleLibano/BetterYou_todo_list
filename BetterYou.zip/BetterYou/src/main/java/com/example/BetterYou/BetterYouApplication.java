package com.example.BetterYou;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BetterYouApplication {

	public static void main(String[] args) {
		SpringApplication.run(BetterYouApplication.class, args);
	}

}
